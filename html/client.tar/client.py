#!/usr/bin/python 
import commands,os 
a=commands.getstatusoutput('iscsiadm --mode discoverydb --type sendtargets --portal 192.168.1.254 --discover') 
b=commands.getstatusoutput('iscsiadm --mode node --targetname mm --portal 192.168.1.254:3260 --login') 
print a 
print b 
