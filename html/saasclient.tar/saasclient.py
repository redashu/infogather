#!/usr/bin/python 
import commands,os 
commands.getstatusoutput('ssh -X aa@192.168.1.254 gedit ') 
